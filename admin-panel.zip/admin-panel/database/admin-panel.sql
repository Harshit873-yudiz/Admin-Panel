-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 16, 2020 at 08:01 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin-panel`
--

-- --------------------------------------------------------

--
-- Table structure for table `categorytag`
--

CREATE TABLE `categorytag` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categorytag`
--

INSERT INTO `categorytag` (`id`, `title`, `description`, `slug`, `type`) VALUES
(2, 'world', 'dfsd', 'world', 2),
(6, 'category 1', 'hello world', 'category-1', 1),
(7, 'category 2', 'kjsdfhsdkj', 'category-2', 1),
(8, 'tag 1', 'kjhkjh', 'tag-1', 2),
(9, 'category 3', 'jll', 'category-3', 1),
(10, 'tag 2', 'jkhkjh', 'tag-2', 2),
(11, 'tag 3', 'jkhjk', 'tag-3', 2),
(12, 'category 4', 'jdfghjkh', 'category-4', 1);

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `status` varchar(15) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  `type` int(11) NOT NULL,
  `trash` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `title`, `description`, `status`, `slug`, `date`, `type`, `trash`) VALUES
(226, 'page 1', 'jkghdfjkg', 'publish', 'page-1', '2020-01-15 19:04:57', 3, 0),
(235, 'blog 1', 'dfhgh', 'publish', 'blog-1', '2020-01-16 10:37:29', 1, 0),
(238, 'blog 2', 'sdhjfjkh', 'draft', 'blog-2', '2020-01-16 11:14:07', 1, 0),
(240, 'page 2', 'sdfhdjkh', 'draft', 'page-2', '2020-01-16 11:15:29', 3, 0),
(241, 'product 1', 'kldfkshdkj', 'trash', 'product-1', '2020-01-16 11:19:10', 2, 0),
(243, 'product 2', 'lsdfds', 'publish', 'product-2', '2020-01-16 11:26:43', 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `postmeta`
--

CREATE TABLE `postmeta` (
  `id` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `field` varchar(200) NOT NULL,
  `fieldvalue` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `postmeta`
--

INSERT INTO `postmeta` (`id`, `postid`, `field`, `fieldvalue`) VALUES
(366, 226, 'image', 'mountain.jpg'),
(389, 235, 'checked_id', 'a:3:{i:0;s:7:\"hgjhghj\";i:1;s:10:\"category 3\";i:2;s:10:\"category 4\";}'),
(390, 235, 'tags', 'a:2:{i:0;s:5:\"world\";i:1;s:5:\"tag 2\";}'),
(391, 235, 'image', 'wp1828918.jpg'),
(397, 238, 'checked_id', 'a:5:{i:0;s:7:\"hgjhghj\";i:1;s:10:\"category 1\";i:2;s:10:\"category 2\";i:3;s:10:\"category 3\";i:4;s:10:\"category 4\";}'),
(398, 238, 'tags', 'a:4:{i:0;s:5:\"world\";i:1;s:5:\"tag 1\";i:2;s:5:\"tag 2\";i:3;s:5:\"tag 3\";}'),
(399, 238, 'image', 'wp1828918.jpg'),
(403, 240, 'image', 'monkey.png'),
(404, 241, 'checked_id', 'a:2:{i:0;s:7:\"hgjhghj\";i:1;s:10:\"category 1\";}'),
(405, 241, 'price', '80'),
(406, 241, 'image', 'download.jpeg'),
(408, 243, 'checked_id', 'a:2:{i:0;s:7:\"hgjhghj\";i:1;s:10:\"category 3\";}'),
(409, 243, 'price', '900'),
(410, 243, 'image', 'wp1828918.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`) VALUES
(4, 'admin', 'admin@example.com', '21232f297a57a5a743894a0e4a801fc3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categorytag`
--
ALTER TABLE `categorytag`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `postmeta`
--
ALTER TABLE `postmeta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `postid` (`postid`) USING BTREE;

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categorytag`
--
ALTER TABLE `categorytag`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=244;

--
-- AUTO_INCREMENT for table `postmeta`
--
ALTER TABLE `postmeta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=411;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
