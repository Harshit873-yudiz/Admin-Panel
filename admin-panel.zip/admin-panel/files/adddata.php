<?php include('menu.php')?>
	<div class="container" style="margin-top: 30px; max-width: 500px;margin-left: 230px;">
		<form  name="registration" method="POST" style="color: red;padding: 30px; margin-top: -300px;">
			<div class="form-group">
				<label for="title" style="color: blue">Title</label>
			    <input type="text" class="form-control" name="title" id="title" placeholder="Enter Title"/>
			</div>
			<div class="form-group">
			  	<label for="description" style="color: blue">Description</label>
			  	<textarea class="form-control rounded-0" name="description" id="description" rows="3"></textarea>
			</div>
			<?php if(isset($_GET['category'])){?>
				<input type="hidden" name="types" value="1">
			<?php }if(isset($_GET['tags'])){?>
				<input type="hidden" name="types" value="2">
			<?php }?>	
			<button type="submit" class="btn btn-primary">Add Data</button>
		</form>
	</div>
	<?php 
	$slug='';
	if (isset($_POST['title'])) {
		$title=$conn->real_escape_string($_REQUEST['title']);
		$description=$conn->real_escape_string($_REQUEST['description']);
		$slug = preg_replace('/[^a-z0-9]+/i', '-', trim(strtolower($_POST["title"])));
		$types=$_POST['types'];
		/**********************category-tag***********************/
			$sql3="INSERT INTO categorytag(title,description,slug,type)
			VALUES('$title','$description','$slug','$types')";
			$conn->query($sql3);	
			//header("location:adddata.php?tags=1&category=1");
			echo $conn->error;	
			
	?>
	<?php }?>
	<!-- **************Display-Tags************* --> 
	<div class="container" style=" max-width: 500px;margin-right: 150px;">
		<table id="example" class="table table-striped table-bordered" style="width: 500px;margin-top: -300px;">
	        <thead>
	            <tr>
	            	<th><input type="checkbox" id="select_all" value=""/></th>	
	                <th>Title</th><th>Description</th><th>Slug</th><th>Action</th>
	            </tr>
	        </thead>
			<?php
				if(isset($_GET['category'])){
					$sql="SELECT * FROM categorytag WHERE type=1";
				}
				else if(isset($_GET['tags'])){
					$sql="SELECT * FROM categorytag WHERE type=2";	
				} 
				if($view=$conn->query($sql)){
					if($view->num_rows>0){
						while ($row=$view->fetch_assoc()) {
						   echo '<tbody><tr>';
			?>
							<td align="center">
								<input type="checkbox" name="checked_id[]" 
								class="checkbox" value="<?php echo $row['id']; ?>"/>
		            		</td>	
							<td><?php  echo $row['title'];?></td>
							<td><?php  echo $row['description'];?></td>
							<td><?php  echo $row['slug'];?></td>	
							<td><a class='showvalue' href='updatedata.php?category=1&tags=1&id=<?php echo $row["id"]?>'>Edit</a>
								<a class='btn btn-primary' onclick='delete_confirm();'>Delete</a></td>		
			<?php		}
					}else{echo 'num_rows error';}
				}else{echo 'view error';}
			?>
		</table><br>
		<input type='submit' class='btn btn-primary' value='Delete' onclick='delete_confirm();'/>
	</div>			
<!-- **************Multile cheeckbox and delete functionality************* -->
	<script type="text/javascript">	
	function delete_confirm(){
	    if($('.checkbox:checked').length > 0){
	        $('.checkbox:checked').each(function(){
	                console.log(this.value);
	                $.ajax({
						url:"del.php",
						type:"POST",
						data:"id="+this.value,
						success:function(data){
							location.reload();
						}
					});
	            });
	        return false;
	    }else{
	        return false;
	    }
	}
	//jquery 
	$(document).ready(function(){ 
	    $('#select_all').on('click',function(){
	        if(this.checked){
	            $('.checkbox').each(function(){
	                this.checked = true;
	            });
	        }else{
	             $('.checkbox').each(function(){
	                this.checked = false;
	            });
	        }
	    });
	    $('.checkbox').on('click',function(){
	        if($('.checkbox:checked').length == $('.checkbox').length){
	            $('#select_all').prop('checked',true);
	        }else{
	            $('#select_all').prop('checked',false);
	        }
	    });
	});
</script>	