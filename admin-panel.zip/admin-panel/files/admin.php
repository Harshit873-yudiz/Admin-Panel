<?php include('menu.php')?>
	 <div id="piechart" style="width: 800px; height: 500px; margin: -290px 243px 0;"></div>

	<!-- pie chart -->
    <?php 
    	include("connection.php");
    	$sql="SELECT status,count(*) as number FROM post GROUP BY status";
    	$view=$conn->query($sql);
    ?>
    <script type="text/javascript" src="../jquery/loader.js"></script>
    <script type="text/javascript">
    	google.charts.load('current', {'packages':['corechart']});
    	google.charts.setOnLoadCallback(drawChart);
		function drawChart() {
			var data = google.visualization.arrayToDataTable([
				['status','number'],
				<?php 
					while ($row=$view->fetch_assoc()) {
					    echo "['".$row['status']."',".$row['number']."],";
					}
				?>
			]);
			var options = {
          		title: 'Blog post status',
          		pieHole:0.6
        	};
        	var chart =new google.visualization.PieChart(document.getElementById('piechart'));
        	chart.draw(data, options);
		}	
    </script>
</body>
</html>