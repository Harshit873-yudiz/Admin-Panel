<?php
 		$conn=new mysqli("localhost","root","","admin-panel");

 		//check connection
 		if($conn->connect_error){
			die("connection failed:".$conn->connect_error);
		}
	 ?>