<?php 

	if(isset($_POST['id'])){
		include('connection.php');
		//print_r($_POST['id']);
		$id=$_POST['id'];
		$sql2="DELETE FROM categorytag WHERE id=$id";
		$conn->query($sql2);
	}
?>
<?php 

	if(isset($_POST['id'])){
		include('connection.php');
		//print_r($_POST['id']);
		$id=$_POST['id'];
		$sql6="DELETE FROM post WHERE id=$id";
		$conn->query($sql6);
		$sql7="DELETE FROM postmeta WHERE postid=$id";
		$conn->query($sql7);
	}
?>
