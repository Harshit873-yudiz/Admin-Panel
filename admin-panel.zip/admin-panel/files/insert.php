<?php include('menu.php')?>
<div class="container" style="margin-top: 30px; max-width: 500px;">
	<form  name="registration" method="POST" style="color: red;padding: 30px; margin-top: -246px;" enctype="multipart/form-data">
		<h2 style="color: blue"><u>Add-Post</u></h2>
		<div class="form-group">
			<label for="title" style="color: blue">Title</label>
		    <input type="text" class="form-control" name="title" id="title" placeholder="Enter Title"/>
		</div>
		<div class="form-group">
		  	<label for="description" style="color: blue">Description</label>
		  	<textarea class="form-control rounded-0" name="description" id="description" rows="3"></textarea>
		</div>
		<div class="form-group">
			<label for="file" style="color: blue">Upload Image</label>
			<input type="file" class="form-control" name="fileToUpload" id="fileToUpload">
		</div>
		<?php if (isset($_GET['blog'])||isset($_GET['product'])) {?>
			<label style="color: blue">Category</label>
			<div class="checkbox"style="color: black">
				<table class="bordered">
					<?php 
						include('connection.php');
						$sql="SELECT title FROM categorytag WHERE type=1";
						$result=$conn->query($sql);
						while($row = mysqli_fetch_array($result)){
					?>
					<tr>
						<td><?php echo $row['title'];?>	</td>
						<td>
							<input type="checkbox" name="checked_id[]" class="checkbox" value="<?php echo $row['title'];?>"/>
						</td>
					<?php }?>
					</tr>
				</table>
			</div><br>
		<?php }if (isset($_GET['product'])) {?>
		<div class="form-group">
			<label for="price" style="color: blue">price</label>
		    <input type="text" class="form-control" name="price" id="price" placeholder="Enter Title"/>
		</div>	
	<?php }?>
		<label for="status" style="color: blue">Status</label>
		<select class="form-control" name="status">
				<option value="">Select-option</option>
				<option value="publish">Publish</option>
				<option value="draft">Draft</option>
				<option value="trash">Trash</option>
		</select>
		<?php if (isset($_GET['blog'])) {?>
			<div class="form-group" style="color: black">
				<label for="option" style="color: blue">Tags</label>
				<select id="option" name="tags[]"  multiple placeholder="select Tags" data-jcf='{"wrapNative": false, "wrapNativeOnMobile": false, "useCustomScroll": false, "multipleCompactStyle": true}'>	
					<?php 
						$sql="SELECT title FROM categorytag WHERE type=2";
						$result=$conn->query($sql);
						while($row = mysqli_fetch_array($result)){
					?>
							<option value="<?php print_r($row['title']);?>">
								<?php echo $row['title'];?>
							</option>
						
					<?php }?>
				</select>
			</div><br>
		<?php }?><br>
		<?php if(isset($_GET['blog'])){?>
			<input type="hidden" name="types" value="1">
		<?php }if(isset($_GET['product'])){?>
			<input type="hidden" name="types" value="2">
		<?php }if(isset($_GET['pages'])){?>
			<input type="hidden" name="types" value="3">
		<?php }?>					
		<button type="submit" class="btn btn-primary" name="submit">Add Data</button>
	</form>
</div>
<?php
	$fileToUpload="";
	$types="";
	include_once("connection.php"); 
	//print_r($_POST);
	if (isset($_POST['submit'])) {
		$title=$conn->real_escape_string($_REQUEST['title']);
		$description=$conn->real_escape_string($_REQUEST['description']);
		$status=$conn->real_escape_string($_REQUEST['status']);
		$types=$_POST['types'];
		//checkbox
		if (isset($_GET['blog'])||isset($_GET['product'])) {
			$category=$_REQUEST['checked_id'];
			$category=serialize($category);
			if ($conn->query($category)) {
				$category=array();
				while ($row=mysql_fetch_assoc($category)) {
				   	$category[] = $row;
				   	print_r($category);
				}
			}
		}	
		//tags
		if (isset($_GET['blog'])) {
			$tag=$_REQUEST['tags'];
			$tags=serialize($tag);
			if ($conn->query($tags)) {
				$tags=array();
				while ($row=mysql_fetch_assoc($tags)) {
				   	$tags[] = $row;
				   	print_r($tags);
				}
			}
		}	
		//slug		
		$slug = preg_replace('/[^a-z0-9]+/i', '-', 
		        trim(strtolower($_POST["title"]))); 
		$sql1="INSERT INTO post(title,description,status,slug,type)
		VALUES('$title','$description','$status','$slug','$types')";
		$conn->query($sql1);	
		echo $conn->error;
	}
	$lastid = mysqli_insert_id($conn); 
	foreach ($_POST as $key=>$value) {	
 		if ($key=='title'||$key=='description'||$key=='status'||$key=='slug'||$key=='type'||$key=='date'||$key=='types'||$key=='submit') {
 			continue;
 		}
 		if (is_array($_POST[$key])==true) {
        	$value=serialize($value);
        }
		$sql2="INSERT INTO postmeta(postid,field,fieldvalue)
        VALUES($lastid,'$key','$value')";
        $conn->query($sql2);	
	}
	if(isset($_FILES["fileToUpload"])){
    	$target_dir="upload/";
		$target_file=$target_dir.basename($_FILES["fileToUpload"]["name"]);
		$uploadOk =1;
		$imageFileType=strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		// Check if image file is a actual image or fake image
		if(isset($_POST["submit"])) {
		    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
		    if($check !== false) {
		        echo "" . $check["mime"] . ".";
		        $uploadOk = 1;
		    } else {
		        echo "File is not an image.";
		        $uploadOk = 0;
		    }
		}
		//check if file is already exist or not?
		if(file_exists($target_file)){
			//echo "file already exist";
			$uploadOk =0;
		}
		// Allow certain file formats
		if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
			&& $imageFileType != "gif" ) {
		    // echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
		    $uploadOk = 0;
		} 
		else {
		    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
		        $filename= $_FILES["fileToUpload"]["name"];
				$sql2="INSERT INTO postmeta(postid,field,fieldvalue)
			        VALUES($lastid,'image','$filename')";
			    $conn->query($sql2);
				print_r($lastid);
		    } else {
		        echo "Sorry, there was an error uploading your file.";
		    }
		}
	}else{
		echo $conn->error;
	}		
?>		
