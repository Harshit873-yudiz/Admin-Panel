<?php
include 'connection.php';
session_start(); 
//print_r($_SESSION['user']);
if (!isset($_SESSION['user'])) {
    header('Location: ../index.php');
	// print_r($_SESSION['user']);
	// echo '<br>string';
}


?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="../css/style.css">

	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<link rel="stylesheet" href="../css/jcf.css">
	<link rel="stylesheet" type="text/css" href="../css/util.css">
	<script type="text/javascript" src="../jquery/jquery.js"></script>
	<script type="text/javascript" src="../jquery/jcf.js"></script>
	<script type="text/javascript" src="../jquery/jcf.select.js"></script>
	<script type="text/javascript" src="../jquery/jcf.scrollable.js"></script>

	<script type="text/javascript" src="../jquery/jquery-3.4.1.slim.min.js"></script>
	<script type="text/javascript" src="../jquery/popper.min.js"></script>
	<script type="text/javascript" src="../jquery/bootstrap.min.js"></script>

	<script type="text/javascript" src="../jquery/jquery.min.js"></script>
	<script type="text/javascript" src="../jquery/jquery.validate.min.js"></script>
	<script type="text/javascript" src="../jquery/additional-methods.min.js"></script>
	<script type="text/javascript" src="../jquery/jquery-ui.js"></script>
	<script type="text/javascript" src="../jquery/formvalidation.js"></script>
	<script type="text/javascript" src="../jquery/jsapi_compiled_ui_module.js"></script>
	<script>
		$(function() {
			jcf.replaceAll();
		});
	</script>
</head>
<body>
	<div class="vertical-menu">
		<a href="admin.php" class="active">Home</a>
		<div class="dropdown show">
	  		<a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Blog</a>
		  	<div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
			    	<a class="dropdown-item" href="insert.php?blog=1">Add-new</a>
			      	<a class="dropdown-item" href="view-blog.php">View-Blog</a>
			      	<a class="dropdown-item" href="adddata.php?category=1">Add-Category</a>
			      	<a class="dropdown-item" href="adddata.php?tags=1">Add-Tags</a>
			  	</div>
		</div>
		<div class="dropdown show">
	  		<a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Product</a>
		  	<div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
			    	<a class="dropdown-item" href="insert.php?product=1">Add-Product</a>
			      	<a class="dropdown-item" href="view.php?product=2">View-Product</a>
			</div>
		</div>  
		<div class="dropdown show">
	  		<a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Pages</a>
		  	<div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
			    	<a class="dropdown-item" href="insert.php?pages=1">Add-Pages</a>
			      	<a class="dropdown-item" href="view.php?pages=2">View-Pages</a>
			</div>
		</div>
		<a href="logout.php" class="active">Logout</a>
	</div> 