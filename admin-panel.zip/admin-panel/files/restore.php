<?php  
	if (isset($_POST['id'])) {
		include('connection.php');
		print_r($_POST['id']);
		$id=$_POST['id'];
		echo $id;
		$sql="UPDATE post SET trash=0 WHERE id=$id";
		$conn->query($sql);
		$conn->close();
	}
?>