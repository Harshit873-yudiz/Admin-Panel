<?php include('menu.php')?>
	<?php
		include('connection.php');
		if (isset($_GET['id'])) {
			//print_r($_GET['id']);
			if (isset($_POST['title'])) {
				$title=$conn->real_escape_string($_REQUEST['title']);
				$description=$conn->real_escape_string($_REQUEST['description']);
				$slug = preg_replace('/[^a-z0-9]+/i', '-', 
			        trim(strtolower($_POST["title"])));
				$status=$conn->real_escape_string($_REQUEST['status']);
				$sql3="UPDATE post SET title='$title', description='$description',slug='$slug',status='$status' WHERE id=".$_GET['id']."";
				$conn->query($sql3);	
			}
		}
		$conn->close();
	?>
	<?php
		include("connection.php");
		if(isset($_GET['id'])){
			if(isset($_FILES["fileToUpload"])){
		        	
	        	$target_dir="upload/";
				$target_file=$target_dir.basename($_FILES["fileToUpload"]["name"]);
				$uploadOk =1;
				$imageFileType=strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

				// Check if image file is a actual image or fake image
				if(isset($_POST["submit"])) {
				    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
				    if($check !== false) {
				        echo "File is an image - " . $check["mime"] . ".";
				        $uploadOk = 1;
				    } else {
				        echo "File is not an image.";
				        $uploadOk = 0;
				    }
				}
				
				//check if file is already exist or not?
				if(file_exists($target_file)){
					//echo "file already exist";
					$uploadOk =1;
				}

				// Check file size
				if ($_FILES["fileToUpload"]["size"] <0) {
				   // echo "Sorry, your file is too large.";
				    $uploadOk = 0;
				}

				// Allow certain file formats
				if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
					&& $imageFileType != "gif" ) {
				  //  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				    $uploadOk = 0;
				}

				// Check if $uploadOk is set to 0 by an error
				if ($uploadOk == 0) {
				   // echo "Sorry, your file was not uploaded.";
				// if everything is ok, try to upload file
				} 
				else {
				    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
				        // echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
				        
				        $filename= $_FILES["fileToUpload"]["name"];
				        
				        //print id of one table to another
					 	$lastid= mysqli_insert_id($conn);
					 	//insert into postmeta

						 $sql4="UPDATE postmeta SET field='image',fieldvalue='$filename' WHERE field='image' AND postid=".$_GET['id']."";
	        			$conn->query($sql4);	

						//print_r($filename);
						
				    } else {
				        echo "Sorry, there was an error uploading your file.";
				    }
				}
			}
			else{
				echo $conn->error;
			}
		}
		$conn->close();
	?>
	<?php
		include('connection.php');
		if(isset($_POST['checked_id'])){
			$checked_id =serialize($_POST['checked_id']);
			$sql5="UPDATE postmeta SET field='checked_id',fieldvalue='$checked_id' WHERE field='checked_id' AND postid=".$_GET['id']."";
		    $conn->query($sql5);
		}
		if(isset($_POST['tags'])){
			$tags =serialize($_POST['tags']);
			$sql5="UPDATE postmeta SET field='tags',fieldvalue='$tags' WHERE field='tags' AND postid=".$_GET['id']."";
		    $conn->query($sql5);
		}
	?>
	<!-- Display value -->
	<?php
		$title="";
		$description="";
		$target_file1="";
		$checked_id=array();
		$tags=array();
		$status=array();
		include("connection.php");
		if (isset($_GET['id'])) {
			//print_r ($_GET['id']);
			$sql1="SELECT * FROM post WHERE id=".$_GET['id']."";
			if ($view1=$conn->query($sql1)) {
				$row1=$view1->fetch_assoc();
				$title=$row1['title'];
				$description=$row1['description'];
				
				//print_r($description);
			}
			else{
				die("Data Not Found Error : ".$conn->error);
			}
		}

		if (isset($_GET['id'])) {
			$sql2="SELECT * FROM postmeta WHERE postid=".$_GET['id']."";
			if($view2=$conn->query($sql2)){
				while($row2 = $view2->fetch_assoc()){
					if($row2['field']=='image'){
							$target_file1= "upload/". $row2['fieldvalue'];	
					}
					if($row2['field']=='checked_id'){
						$checked_id=unserialize($row2['fieldvalue']);
					}
					if($row2['field']=='tags'){
						$tags=unserialize($row2['fieldvalue']);
						// print_r($hobby);
					}
				}		
			}
		}
	?>

	 <div class="container" style="margin-top: 30px; max-width: 500px;">
		<form  name="registration" method="POST" style="color: red;padding: 30px; margin-top: -246px;" enctype="multipart/form-data">
			<h2 style="color: blue"><u>Update-Post</u></h2>
			
			<div class="form-group">
				<label for="title" style="color: blue">Title</label>
				<input type="text" class="form-control" name="title" id="title" placeholder="Enter Title" value="<?php echo $title;?>"/>
			</div>
			 <div class="form-group">
				<label for="description" style="color: blue">Description</label>
				<textarea class="form-control rounded-0" name="description" id="description" rows="3"><?php echo $description;?></textarea>
			</div>
			<div class="form-group">
				<label for="file" style="color: blue">Upload Image</label>
				<input type="file" class="form-control" name="fileToUpload" id="fileToUpload" value="<?php echo $target_file;?>">
				<?php echo "<img src='".$target_file1."' height=150 width=100 />";?>
			</div>
			<?php if (isset($_GET['blog'])||isset($_GET['product'])) {?>
				<label style="color: blue">Category</label>
				<div class="checkbox"style="color: black">
					<table class="bordered">
						<?php 
							include('connection.php');
							if (isset($_GET['id'])) {
								//print_r($_GET['id']);
								$id=$_GET['id'];
								$sql="SELECT title FROM categorytag WHERE type=1";
								$result=$conn->query($sql);
								while($row = mysqli_fetch_array($result)){
						?>
									<tr>
										<td><?php echo $row['title'];?>	</td>
										<td>
											<input type="checkbox" name="checked_id[]" class="checkbox" value="<?php echo $row['title']?>"
											<?php 
												//print_r($checked_id);
												if (in_array($row['title'],$checked_id)) {
													echo 'checked';
												}
											?>	
											/>
											
										</td>
									</tr>	
					<?php
								}
							}
					?>

					</table>
				</div><br>
			<?php }if (isset($_GET['blog'])) {?>
				<div class="form-group" style="color: black">
					<label for="option" style="color: blue">Tags</label>
					<select id="option" name="tags[]"  multiple placeholder="select Tags" data-jcf='{"wrapNative": false, "wrapNativeOnMobile": false, "useCustomScroll": false, "multipleCompactStyle": true}'>	
						<?php 
							$sql="SELECT title FROM categorytag WHERE type=2";
							$result=$conn->query($sql);
							while($row = mysqli_fetch_array($result)){
						?>			
								<?php
									if(in_array($row['title'],$tags)){
										echo '<option value="'.$row['title'].'"selected="selected">'.$row['title'].'</option>';
									}
									else{
										echo '<option value="'.$row['title'].'">'.$row['title'].'</option>';
									}	
								?>
						<?php }?>
					</select>
				</div>
			<?php }?>	
			<label for="status" style="color: blue">Status</label>
			<select class="form-control" name="status">
				<option value="">Select-option</option>
				<option value="publish"
						<?php  if (in_array("publish",$status)) {
							echo "selected";
						}?>>Publish
				</option>
				<option value="draft" 
						<?php  if (in_array("draft",$status)) {
						echo "selected";
						}?>>Draft
				</option>
				<option value="trash"
						<?php  if (in_array("trash",$status)) {
							echo "selected";
						}?>>Trash
				</option>
			</select>
			<br>
			<button type="submit" class="btn btn-primary">Add Data</button> 
		</form><br><br>
	</div>	
	<script>
		$(document).ready(function() {
			jcf.replaceAll();
		});
	</script>
</body>
</html>