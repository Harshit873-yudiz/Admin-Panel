<?php include('menu.php')?>

<?php
		include('connection.php');
		if (isset($_GET['id'])) {
			//print_r($_GET['id']);
			if (isset($_POST['title'])) {
				$title=$conn->real_escape_string($_REQUEST['title']);
				$description=$conn->real_escape_string($_REQUEST['description']);
				$slug = preg_replace('/[^a-z0-9]+/i', '-', 
			        trim(strtolower($_POST["title"])));
				/****************category**************************/
				if(isset($_GET['category'])){
					$sql3="UPDATE categorytag SET title='$title', description='$description',slug='$slug' WHERE id=".$_GET['id']."";
					$conn->query($sql3);
				}
				/****************Tags**************************/
				if(isset($_GET['tags'])){
					$sql4="UPDATE categorytag SET title='$title', description='$description',slug='$slug' WHERE id=".$_GET['id']."";
					$conn->query($sql4);
				}	
			}
		}
		$conn->close();
	?>
<?php
	$title="";
	$description="";
	include("connection.php");
	if (isset($_GET['id'])) {
		if(isset($_GET['tags'])){
			$sql1="SELECT * FROM categorytag WHERE id=".$_GET['id']."";
		}
		if(isset($_GET['category'])){
			$sql1="SELECT * FROM categorytag WHERE id=".$_GET['id']."";
		}	
		if($view1=$conn->query($sql1)){
			$row1=$view1->fetch_assoc();
			$title=$row1['title'];
			$description=$row1['description'];
		}
	}
	$conn->close();
?>
<div class="container" style="margin-top: 30px; max-width: 500px;margin-left: 230px;">
		<form  name="registration" method="POST" style="color: red;padding: 30px; margin-top: -246px;">
			<h2 style="color: blue"><u>Update</u></h2>
			
			<div class="form-group">
				<label for="title" style="color: blue">Category Title</label>
			    <input type="text" class="form-control" name="title" id="title" placeholder="Enter Blog Title" value="<?php echo $title;?>" />
			</div>
			<div class="form-group">
			  	<label for="description" style="color: blue">Description</label>
			  	<textarea class="form-control rounded-0" name="description" id="description" rows="3"><?php echo $description;?></textarea>
			</div>
			<button type="submit" class="btn btn-primary">Update Tags</button>
		</form>
	</div>
</body>
</html>
