<?php include('menu.php');?>
<form name="bulk_action_form" method="post" onSubmit="
		return delete_confirm();" enctype="multipart/form-data">
	<div class="container" style="max-width:850px;">
	<table id="example" class="table" style="margin-top: -180px;">
        <thead>
            <tr>
            	<th>Action</th>
            	<th><input type="checkbox" id="select_all" value=""/></th>
                <th>Title</th>
                <th>Slug</th>
                <th></th>
                <th>category</th>
                <th>Tag</th>
            </tr>
        </thead>
	<?php
		include("connection.php"); 
		$sql="SELECT * FROM post WHERE trash=0 AND type=1";
		if($view=$conn->query($sql)){
			if($view->num_rows>0){
				while ($row=$view->fetch_assoc()) {
				   echo '<tbody><tr>
				   ';
	?>			
					<td><?php
							echo "<button class='showvalue'onclick=\"window.location.href='update.php?blog=1&id=".$row["id"]."';\">Edit</button>";
					 		echo"<input type='submit' class='btn btn-primary' value='Trash'/>"
					 	?>
    				</td>	
					<td align="center">
						<input type="checkbox" name="checked_id[]" 
						class="checkbox" value="<?php echo $row['id']; ?>"/>
	            	</td>
					<td><?php echo $row['title'];?><br><br>
						<p style="font-size: smaller;">
							Status:<?php echo $row['status'];?>
						</p>
					</td>	
					<td><?php echo $row['slug']?></td>
	<?php		
					$sql1="SELECT * FROM postmeta where postid='".$row['id']."'";
					//print_r ($row['id']);
					if($view1=$conn->query($sql1)){
						if($view1->num_rows>0){
							while ($row1=$view1->fetch_assoc()) {	
		?>
								<td><?php 
										if($row1['field']=='tags'){
											$category1=unserialize($row1['fieldvalue']);
											//print_r($category1);
											$arr=implode(",", $category1);
											print_r($arr);
										}		
									?>
								</td>								
								<td><?php 
									   	//print_r($arr);
									   	if($row1['field']=='checked_id'){
											$category1=unserialize($row1['fieldvalue']);
											//print_r($category1);
											$arr=implode(",", $category1);
											print_r($arr);
										}
									?>
								</td>				
		<?php	
							}
						}
					}	
				}
			}
			else{
				echo 'Data not available';
			}

			
		}
		else{
			echo 'view error';
		}
	?>
	</table>
	<input type="submit" class="btn btn-primary" value="Trash"/>
	
	<a href="trash.php" class="btn btn-primary">View Trash</a>
</form>	
<script type="text/javascript">
		
		function delete_confirm(){
		    if($('.checkbox:checked').length > 0){
		        $('.checkbox:checked').each(function(){
		                //console.log(this.value);
		                $.ajax({
							url:"trash.php",
							type:"POST",
							data:"id="+this.value,
							success:function(data){
								console.log(data);	
								location.reload(true);
							}
						});
		            });
		        return false;
		    }
		    else{
		        //alert('Select at least 1 record to trash.');
		        return false;
		    }
		}

		//jquery 

		$(document).ready(function(){
		    $('#select_all').on('click',function(){
		        if(this.checked){
		            $('.checkbox').each(function(){
		                this.checked = true;
		            });
		        }
		        else{
		             $('.checkbox').each(function(){
		                this.checked = false;
		            });
		        }
		    });

		    $('.checkbox').on('click',function(){
		        if($('.checkbox:checked').length == $('.checkbox').length){
		            $('#select_all').prop('checked',true);
		        }
		        else{
		            $('#select_all').prop('checked',false);
		        }
		    });
		});
	</script>	
	
</body>
</html>