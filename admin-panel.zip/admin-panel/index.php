<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login-Page</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<script type="text/javascript" src="jquery/jquery-3.4.1.slim.min.js"></script>
	<script type="text/javascript" src="jquery/popper.min.js"></script>
	<script type="text/javascript" src="jquery/bootstrap.min.js"></script>

	<script type="text/javascript" src="jquery/jquery.min.js"></script>
	<script type="text/javascript" src="jquery/jquery.validate.min.js"></script>
	<script type="text/javascript" src="jquery/additional-methods.min.js"></script>
	<script type="text/javascript" src="jquery/jquery-ui.js"></script>
</head>
<body>
	<?php
		if( isset($_POST['uname']) and isset($_POST['pwd']) ) {
			include('files/connection.php'); //code is given below (used for database connection)
			$user=$_POST['uname'];
			$pass=$_POST['pwd'];

			$sql="SELECT * FROM user WHERE name='".$user."' AND password='".md5($pass)."'";
			//$password=md5($pass);
			//$sql="INSERT into user(name,password)VALUES('admin','$password')";
			if($result=$conn->query($sql)){
				if($row=$result->fetch_assoc()){
					if(!$row){
						header("Location: index.php");
						echo 'something wrong';
					}
					else{
				        session_start();
				        $_SESSION['user']=$user;
						header('location: files/admin.php');
						echo $_SESSION['user'];
					}
				}
			}	
		}
	?>
	<div class="container" style="margin-top: 30px;max-width: 500px">
		<form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST" name="registration" style="color: red;padding: 30px;" enctype="multipart/form-data">

			<h2 style="color: blue"><u>User Login</u></h2>
			<div class="form-group">
				<label for="name" style="color: blue"> Name</label>
			    <input type="text" class="form-control" name="uname" id="name" placeholder="name" required/>
			</div>	
			<div class="form-group">    
			    <label for="password" style="color: blue">Password</label>
			    <input type="password" class="form-control" id="password" name="pwd" placeholder="password" required />
			</div>
			<button type="submit" id='login' class="btn btn-primary">Login</button>	
		</form>
	</div>		
</body>
</html>