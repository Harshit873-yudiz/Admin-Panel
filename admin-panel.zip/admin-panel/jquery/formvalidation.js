$("document").ready(function() {
  $("form[name='registration']").validate({
    rules: {
      name:{
        required:true,
      },
      password: {
        required: true,
      },
    },
    messages: {
      name:{
        required:"Enter name",
      },
      password: {
        required: "Please Enter password",
      },

    },
    errorElement : 'div',
      submitHandler: function(form) {
        $("form").reset();
        form.submit();
      },
       highlight: function (element, errorClass) {
        $(element).closest('.form-group').addClass('has-error');
      },
      unhighlight: function (element, errorClass) {
        $(element).closest('.form-group').removeClass('has-error');
      },
      errorPlacement: function(error, element) {
        //error.insertAfter(element);
        error.appendTo(element.parent());       
      }

  });
  


// $("#viewdata").click(function(){
//     $()       
// });

$.validator.addMethod(
      "regex",
      function(value, element, regexp) {
          var check = false;
          var re = new RegExp(regexp);
          return this.optional(element) || re.test(value);
      }
);
});